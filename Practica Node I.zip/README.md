## API Documentation:

## To install:

npm install

### To run the first time the database:

npm run install_db

This command will be execute the database with the ads

### Api Methods

GET 'localhost:3000/apiv1/anuncios'
GET 'localhost:3000/apiv1/tags'
POST 'localhost:3000/apiv1/creacion'

### List of ads

GET localhost:3000/apiv1/anuncios

** Default limit is 10000 **

### List Of tags

GET localhost:3000/apiv1/tags

### Create and Ad

POST localhost:3000/apiv1/creacion

### Filters:

- Pagination
- Filter by name
- Filter by price (min/max)
- Filter by tags

### Examples:

### Hope this API and its documentation helps you :)
